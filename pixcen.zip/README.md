# Low level pixel editor for C64

## Windows

Precompiled binaries for x86 and amd64 can be downloaded from:
http://binarybone.com/pixcen/pixcen.zip
http://binarybone.com/pixcen/pixcen64.zip

To build Pixcen I recommend Visual Studio 2015 Community Edition that can be downloaded for free.

## MacOS

This project provides a MacOS port of Pixcen. We use the
original C++ code for reading/writing the file formats.

To compile the MacOS versoin use the XCode IDE from Apple.

This project was built with the older Storyboard-GUI-System
which gives it a deployment target of *MacOS 10.15*.

This means it is backwards compatible down to macOS Catalina.
It might break with XCode-Updates. At the time of writing 
Catalina is still supported. It was tested on MacOS Big Sur
and on MacOS Tahoe 26.4 and XCode Version 26.4.

Congratulations on more than 10 years of operation. This port 
was started in 2020 and was released in 2026. It took a lot of 
work and hasn’t been tested as thoroughly as the Windows version. 
Therefore, it may contain bugs. Use at your own risk. The usability 
has also been slightly adapted for macOS and touchpad operation.

It was fun reading the original code. I promised this project to our 
graphic designer, mgt, back in 2020 so she could use it on her MacBook Air. 
And I had truly underestimated the project. At first glance, this pixel 
editor seems simple. But it’s a real challenge. 

My respect goes to Hammarberg. 

### MacOS Gatekeeper and error messages

For some time now, Apple has required that applications be digitally signed. 
There are two types of code signing: *ad hoc* and *notarization by Apple*. 
If an app has been signed by Apple, it will always work. 
The operating system assigns a so-called quarantine flag to every file. 
*As soon as a file is loaded via a disk, USB drive, or the internet, 
the quarantine flag is set.* Any application marked in this way 
will not launch on macOS, even though it works. 
It appears to be broken. But it's not.

That's not a bug; it's actually a feature of the operating system. 
Unfortunately, the error message is worded as if our application were broken. 
This binary version was simply signed ad hoc. Therefore, the "error" is normal.

### How to Run it

Here are the steps you need to follow to run the app. On older operating systems, 
simply right-click on pixcen.app (Ctrl+Click or two-finger tap on the touchpad). 
A pop-up menu will appear, which will include an "Open" option. The application will then launch. 

On newer operating systems, such as Tahoe 26.4, you can also try right-clicking and selecting "Open."
Or double click it to try to start it. You first have to try to start it once for the app
to be blocked. Then it appears in the System Preferences.

Next, open System Preferences (Apple menu/System Preferences).  There, select "Privacy & Security." 
In the details that appear, scroll all the way to the bottom. You should see the "Security" section 
and the entry "Allow apps from." Below that, there should be an entry stating that pixcen.app has been 
blocked. Next to it, there should be a "Run Anyway" button. 

Please adapt these instructions accordingly for your local language in the setup. 

This method allows you to remove an ad-hoc signed app from quarantine once after it has been 
downloaded from the internet. 

The app should now work on your computer without any issues.